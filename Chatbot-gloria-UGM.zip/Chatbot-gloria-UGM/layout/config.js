const mysql = require('mysql2');

const connection = mysql.createConnection({
    host: 'p3plzcpnl507504.prod.phx3.secureserver.net',
    user: 'AdminUgmia',
    password: 'benjabece2712',
    database: 'ugm-gloria-ia',
    connectTimeout: 30000
});

connection.connect((err) => {
    if (err) {
        console.error('Error connecting to the database:', err);
        return;
    }
    console.log('Connected to the MySQL server.');
});

module.exports = connection;
